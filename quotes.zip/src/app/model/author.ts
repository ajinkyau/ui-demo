export interface Author {
    died: String,
    born: String,
    profession: String,
    intro: String,
    name: String,
    id: String
}